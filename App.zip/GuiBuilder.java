import java.util.ArrayList;

public class GuiBuilder {
    //Die einselne Komponenten des Frames
    private static String lighthorizontal = "\u2500";
    private static String lightvertical = "\u2502";
    private static String lightdownright = "\u250C";
    private static String lightdownleft = "\u2510";
    private static String lightupright= "\u2514";
    private static String lightupleft= "\u2518";
    private static String lightCross = "\u253c";
    private static String lightverticalright = "\u251c";
    private static String lightverticalleft = "\u2524";

    //Hilfs Funktion zum Bauen des Guis
    private static String bottomframe(){
        String str = "";
        for(int i = 0; i <= 114;i++){

            switch(i){
                case 0 :
                    str += lightupright;
                    break;
                case 114:
                    str += lightupleft;
                    break;
                default:
                    str += lighthorizontal;
            }
        }
        return str + "\n";
    }
    private static String upperframe(){
        String str = "";
        for(int i = 0; i <= 114;i++){
            switch(i){
                case 0 :
                    str += lightdownright;
                    break;
                case 114:
                    str += lightdownleft;
                    break;
                default:
                    str += lighthorizontal;
            }
        }
        return str + "\n";
    }
    private static String space(int i){
        String str = "";
        for(int x = 0; x < i; x++){
            str += " ";
        }
        return str;
    }
    private static String line(int i){
        String str = "";
        for(int x = 0; x < i; x++){
            str += lighthorizontal;
        }
        return str;
    }
    public static void clear(){
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    }


    public static void showTitle(){
        clear();
        String str = upperframe();
        str += lightvertical + space(50) + "Tempcontrol" + space(52)+lightvertical+"\n";
        str += bottomframe();
        System.out.print(str);
        }
    public static void showBox(String[] list){
        String str = upperframe();
        for(String value : list){
            str += lightvertical+value+space(113-value.length())+lightvertical+"\n";
        }
        str += bottomframe();
                System.out.print(str);

    }
    public static void showBenTable(String[][] strArray){
        String str = upperframe();
        str += lightvertical+" id  "+lightvertical+" Anmeldename                    "+lightvertical+" Name                           "+lightvertical+" Telefon         "+lightvertical+" Berechtigung "+lightvertical+" Status "+lightvertical+"\n";
        for(int i = 0; i <= 114; i++){
            switch (i){
                case 0:
                    str += lightvertical;
                    break;
                case 1:
                case 113:
                    str +=" ";
                    break;
                case 6:
                case 39:
                case 72:
                case 90:
                case 105:
                    str += lightCross;
                    break;
                case 114:
                    str += lightvertical+"\n";
                    break;
                default:
                    str += lighthorizontal;
            }
        }
        for (String[] arr: strArray) {
            // ID | Anmelde | Name | Tele | Bere | Status
            str +=GuiBuilder.lightvertical+" "+arr[0]+space(3-arr[0].length())+" "+GuiBuilder.lightvertical+" "+arr[1]+space(30-arr[1].length())+" "+GuiBuilder.lightvertical+" "+arr[2]+space(30-arr[2].length())+" "+GuiBuilder.lightvertical+" "+arr[3]+space(15-arr[3].length())+" "+GuiBuilder.lightvertical+" "+arr[4]+space(3-arr[4].length())+"          "+GuiBuilder.lightvertical+" "+arr[5]+space(5-arr[5].length())+"  "+GuiBuilder.lightvertical+"\n";
        }
        str += lightverticalright+line(113)+lightverticalleft+"\n";
        str += GuiBuilder.lightvertical +" -1.Return to Menu"+ space(77) +"0.Create New User "+ GuiBuilder.lightvertical+"\n";
        str += bottomframe();
        System.out.println(str);
    }
    public static void showBenTable(String[] arr){
        String str = upperframe();
        str += lightvertical+" id  "+lightvertical+" Anmeldename                    "+lightvertical+" Name                           "+lightvertical+" Telefon         "+lightvertical+" Berechtigung "+lightvertical+" Status "+lightvertical+"\n";
        for(int i = 0; i <= 114; i++){
            switch (i){
                case 0:
                    str += lightvertical;
                    break;
                case 1:
                case 113:
                    str +=" ";
                    break;
                case 6:
                case 39:
                case 72:
                case 90:
                case 105:
                    str += lightCross;
                    break;
                case 114:
                    str += lightvertical+"\n";
                    break;
                default:
                    str += lighthorizontal;
            }
        }
            // ID | Anmelde | Name | Tele | Bere | Status
            str +=GuiBuilder.lightvertical+" "+arr[0]+space(3-arr[0].length())+" "+GuiBuilder.lightvertical+" "+arr[1]+space(30-arr[1].length())+" "+GuiBuilder.lightvertical+" "+arr[2]+space(30-arr[2].length())+" "+GuiBuilder.lightvertical+" "+arr[3]+space(15-arr[3].length())+" "+GuiBuilder.lightvertical+" "+arr[4]+space(3-arr[4].length())+"          "+GuiBuilder.lightvertical+" "+arr[5]+space(5-arr[5].length())+"  "+GuiBuilder.lightvertical+"\n";
        str += lightverticalright+line(113)+lightverticalleft+"\n";
        str += GuiBuilder.lightvertical +" -1.Return"+ space(14) +"1.Werte ändern"+ space(14) +"2.Passwort zurücksetzen"+ space(14) +"3.Dativieren/Aktivieren "+ GuiBuilder.lightvertical+"\n";
        str += bottomframe();
        System.out.println(str);
    }

    public static void showLog(String[][] strArray){
        String str = upperframe();
        str += lightvertical+" ID  "+lightvertical+" Datum der Änderung  "+lightvertical+" MaxTemp "+lightvertical+" Anmeldename                    "+lightvertical+" Sensor "+lightvertical+" Adresse des Sensor              "+lightvertical+"\n";
        for(int i = 0; i <= 114; i++){
            switch (i){
                case 0:
                    str += lightvertical;
                    break;
                case 1:
                case 113:
                    str +=" ";
                    break;
                case 6:
                case 28:
                case 38:
                case 71:
                case 80:
                    str += lightCross;
                    break;
                case 114:
                    str += lightvertical+"\n";
                    break;
                default:
                    str += lighthorizontal;
            }
        }
        for(String[] value : strArray){
            str += lightvertical+" "+value[0]+ space(3-value[0].length())+" "+lightvertical+" "+value[1]+" "+lightvertical+" "+value[2]+ space(3-value[2].length())+"     "+lightvertical+" "+value[3]+ space(30-value[3].length())+" "+lightvertical+" "+value[4]+ space(3-value[4].length())+"    "+lightvertical+" "+value[5]+ space(30-value[5].length())+"  "+lightvertical+"\n";
        }
        str += lightverticalright+line(113)+lightverticalleft+"\n";
        str += GuiBuilder.lightvertical +" -1.Return"+ space(103) +lightvertical +"\n";
        System.out.println(str+bottomframe());

    }
    public static void showTemp(String[][] strArray){
        String str = upperframe();
        str += lightvertical+" ID  | Gemessene Temperatur | Datum               | Sensor | Adresse"+space(45)+lightvertical+"\n";
        for(int i = 0; i <= 114; i++){
            switch (i){
                case 0:
                    str += lightvertical;
                    break;
                case 1:
                case 113:
                    str +=" ";
                    break;
                case 6:
                case 29:
                case 51:
                case 60:
                    str += lightCross;
                    break;
                case 114:
                    str += lightvertical+"\n";
                    break;
                default:
                    str += lighthorizontal;
            }
        }
        for (String[] value: strArray)
            str += lightvertical+" "+value[0]+ space(3-value[0].length())+" | "+value[1]+ space(3-value[1].length())+"                  | "+value[2]+" | "+value[3]+ space(3-value[3].length())+"    | "+value[4]+ space(52-value[4].length())+""+lightvertical+"\n";
        str += lightverticalright+line(113)+lightverticalleft+"\n";
        str += GuiBuilder.lightvertical +" -1.Return"+ space(103) +lightvertical +"\n";
        System.out.println(str+bottomframe());
    }
}
