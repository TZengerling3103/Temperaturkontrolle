import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Log {
    public void menu() throws SQLException {
        int abfrage;
        do{
            GuiBuilder.showTitle();
            showLogs();
            abfrage = UTIL.eingabeint();
            if(abfrage != -1){
                if(!delLog(abfrage)){
                    System.out.println("Fehler ist aufgetreten!");
                }
            }

        }while (abfrage != -1);
    }
    public boolean delLog(int ID){
        //Raphael Pls do this.

        return false;
    }
    public void showLogs() throws SQLException {
        ArrayList<String[]> arrayList = new ArrayList<>();
        ResultSet result = UTIL.getResult("SELECT l.LogID,l.Datum,l.MaxTemp,b.AnmeldeName,s.SensorID,s.Adresse FROM benlog l LEFT JOIN benutzer b on l.BenutzerID = b.BenutzerID LEFT JOIN sensor s on l.SensorID = s.SensorID");
        while(result.next()){
            arrayList.add(new String[]{result.getString("LogID"),result.getString("Datum"),result.getString("MaxTemp"),result.getString("AnmeldeName"),result.getString("SensorID"),result.getString("Adresse")});
        }
        String[][] strngs = new String[arrayList.size()][6];
        strngs = arrayList.toArray(strngs);
        GuiBuilder.showLog(strngs);
    }
}
