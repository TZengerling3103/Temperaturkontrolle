public class Benutzer {
    private int BenutzerID;
    private String Name;
    private String AnmeldeName;
    private String Passwort;
    private String TeleNr;
    private int Berechtigung;
    private boolean Status;


    Benutzer(int benutzerID,String name, String anmeldeName,String passwort,String teleNr, int berechtigung,boolean status){
        BenutzerID = benutzerID;
        Name = name;
        AnmeldeName = anmeldeName;
        Passwort = passwort;
        TeleNr = teleNr;
        Berechtigung = berechtigung;
        Status = status;
    }

    public boolean statusAendern(){
        String Sql = "Update `benutzer` SET Status="+(!Status ? "1":"0")+" WHERE BenutzerID = '"+BenutzerID+"'";
        if(UTIL.execute(Sql)){
            Status = !Status;
            return true;
        }
        return false;
    }

    public void showMainmenu(){
        int abfrage;
        do{
            GuiBuilder.showTitle();
            GuiBuilder.showBenTable(new String[]{""+BenutzerID,Name,AnmeldeName,TeleNr,""+Berechtigung,(Status?"True":"False")});
            abfrage = UTIL.eingabeint();
            switch(abfrage){
                case -1: break;
                case 1: showaendern();break;
                case 2: setPasswort(UTIL.eingabe("Bitte neues Passwort eingeben."));break;
                case 3: System.out.println((statusAendern())?"Status wurde geändert":"Fehler ist aufgetreten"); break;
                default: System.out.println("Bitte Eine genannt Option Wählen.");
            }

        }while(abfrage != -1);
    }
    public void showaendern(){
        int abfrage;
        do{
            GuiBuilder.showTitle();
            GuiBuilder.showBox(new String[] {"  1.Name ändern["+Name+"]","  2.Telefonnummer ändern["+TeleNr+"]","  3.Berechtigung ändern["+Berechtigung+"]"," -1.zurück"});
            abfrage = UTIL.eingabeint();
            switch(abfrage){
                case -1: break;
                case 1: System.out.println((setName(UTIL.eingabe("Geben Sie den Wert ein was sie setzen wollen")))?"Werte wurde geändert":"Es ist ein Fehler aufgetreten"); break;
                case 2: System.out.println((setTeleNr(UTIL.eingabe("Geben Sie den Wert ein was sie setzen wollen")))?"Werte wurde geändert":"Es ist ein Fehler aufgetreten");break;
                case 3: System.out.println((setBerechtigung(UTIL.eingabeint("Geben Sie den Wert ein was sie setzen wollen")))?"Werte wurde geändert":"Es ist ein Fehler aufgetreten");break;
                default: System.out.println("Bitte Eine genannt Option Wählen.");
            }

        }while(abfrage != -1);
    }


    public String getAnmeldeName() {
        return AnmeldeName;
    }
    public int getBenutzerID() {
        return BenutzerID;
    }
    public int getBerechtigung() {
        return Berechtigung;
    }
    public String getName() {
        return Name;
    }
    public String getPasswort() {
        return Passwort;
    }
    public String getTeleNr() {
        return TeleNr;
    }
    public boolean isStatus() {
        return Status;
    }


    public boolean setName(String name) {
        String Sql = "UPDATE `benutzer` SET Name='"+name+"' WHERE BenutzerID = '"+BenutzerID+"';";
        if(UTIL.execute(Sql)){
            Name = name;
            return true;
        }
        return false;
    }
    public boolean setPasswort(String passwort) {
        String Sql = "UPDATE `benutzer` SET Passwort='"+passwort+"' WHERE BenutzerID = '"+BenutzerID+"';";
        if(UTIL.execute(Sql)){
            Passwort = passwort;
            return true;
        }
        return false;
    }
    public boolean setTeleNr(String teleNr) {
        String Sql = "UPDATE `benutzer` SET Telenr='"+teleNr+"' WHERE BenutzerID = '"+BenutzerID+"';";
        if(UTIL.execute(Sql)){
            TeleNr = teleNr;
            return true;
        }
        return false;
    }
    public boolean setBerechtigung(int berechtigung) {
        String Sql = "UPDATE `benutzer` SET Berechtigung="+berechtigung+" WHERE BenutzerID = '"+BenutzerID+"';";
        if(UTIL.execute(Sql)){
            Berechtigung = berechtigung;
            return true;
        }
        return false;
    }
}
