import java.sql.SQLException;

public class App {
    public static void main(String[] args) throws SQLException {
        new UTIL();
        Benutzerverwaltung benVer = new Benutzerverwaltung();
        Log log = new Log();
        Temp temp = new Temp();
        int eingabe;
        do {
            GuiBuilder.showTitle();
            GuiBuilder.showBox(new String[]{"  1.Benutzerverwaltung","  2.Sensordaten bearbeiten","  3.Temperaturdaten bearbeiten","  4.Log-Tabelle ansehen"," -1.Programmbeendne"});
            eingabe = UTIL.eingabeint();
            switch (eingabe){
                case 1:
                    benVer.menu();
                break;
                case 2:break;
                case 3:temp.menu();break;
                case 4:log.menu();break;
                case -1:break;
                default:
                    System.out.println("Bitte machen Sie eine Gültige eingabe");
            }
        }while (eingabe != -1);
    }
}
