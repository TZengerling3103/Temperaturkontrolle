import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Benutzerverwaltung {
    Benutzerverwaltung() {
    }
    public void menu() throws SQLException {
        int abfrage;
        do{
            GuiBuilder.showTitle();
            showUsers();
            abfrage = UTIL.eingabeint();
            if(abfrage == 0){
                creteUser();
            }else if(abfrage == -1){

            }else{
                if(!toUser(abfrage)){
                    System.out.println("Fehler ist aufgetreten!");
                }
            }

        }while (abfrage != -1);
    }
    public void showUsers() throws SQLException{
        ArrayList<String[]> arrayList = new ArrayList<>();
        ResultSet result = UTIL.getResult("SELECT * FROM `benutzer`");
        while(result.next()){
            arrayList.add(new String[]{result.getString("BenutzerID"),result.getString("Name"),result.getString("AnmeldeName"),result.getString("TeleNr"),result.getString("Berechtigung"),(result.getInt("Status")==1?"true":"false")});
        }
        String[][] strngs = new String[arrayList.size()][6];
        strngs = arrayList.toArray(strngs);
        GuiBuilder.showBenTable(strngs);
    }
    public boolean toUser(int ID) throws SQLException{
        Benutzer benutzer = null;
        ResultSet result = UTIL.getResult("SELECT * FROM `benutzer` Where BenutzerID = '"+ID+"'");
        while(result.next()){
            benutzer = new Benutzer(ID, result.getString("Name"), result.getString("AnmeldeName"), result.getString("Passwort"), result.getString("TeleNr"), result.getInt("Berechtigung"), (result.getInt("Status")==1?true:false));
        }
        if(benutzer != null){
            benutzer.showMainmenu();
        }


        return false;
    }
    public void creteUser() {
        //Raphael Pls do this.
    }
}
