import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class UTIL {
    private static Connection connection;
    UTIL(){
        try {
            connection  = DriverManager.getConnection("jdbc:mariadb://localhost:3306/tempcontroll", "root", "");
        } catch (SQLException e) {
            System.out.println("Fehler Beim laden der DatenBank.");
            e.printStackTrace();
            System.exit(0);
        }
    }

    public static boolean execute(String Sql){
        try (PreparedStatement statement = connection.prepareStatement(Sql)) {
            int rows = statement.executeUpdate();
            if(rows > 0){
                return true;
            }

        } catch (SQLException e) {
            System.out.println("Fehler Beim laden der DatenBank.");
            e.printStackTrace();
        }

        return false;
    }

    public static ResultSet getResult(String Sql){
        try (PreparedStatement statement = connection.prepareStatement(Sql)) {
            return statement.executeQuery();
        } catch (SQLException e) {
            System.out.println("Fehler Beim laden der DatenBank.");
            e.printStackTrace();
        }
        return null;
    }

    public static int eingabeint(String str){
        System.out.print(str+"\nIhre eingabe:");
        Scanner sc = new Scanner(System.in);
        try{
            return sc.nextInt();
        }catch(InputMismatchException err){
            System.out.println("Sie haben eine Falsch Eingabe getätig.");
            return eingabeint(str);
        }

    }
    public static int eingabeint(){
        System.out.print("Ihre eingabe:");
        Scanner sc = new Scanner(System.in);
        try{
            return sc.nextInt();
        }catch(InputMismatchException err){
            System.out.println("Sie haben eine Falsch Eingabe getätig.");
            return eingabeint();
        }

    }

    public static String eingabe(String str){
        System.out.print(str+"\nIhre eingabe:");
        Scanner sc = new Scanner(System.in);
        try{
            return sc.next().replace("\\", "\\\\").replace("\"", "\\\"").replace("'", "\\'");
        }catch(InputMismatchException err){
            System.out.println("Sie haben eine Falsch Eingabe getätig.");
            return eingabe(str);
        }

    }


}
